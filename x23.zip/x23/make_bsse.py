from pyscf.pbc import gto
from zflow.pyscf_helper.bsse_helper import bsse_molecular_crystal
import numpy as np
from pathlib import Path
import argparse
parser = argparse.ArgumentParser()
parser.add_argument('-f', '--file', type=str, help='specify the name of geometry file to use', required=True)
parser.add_argument('-t', '--tol', type=str, help='specify a specific tolerance for shell logic.')
args = parser.parse_args()

file_path = Path("/mnt/home/yliang/ceph/crystals/geometries/x23")
save_path = Path("/mnt/home/yliang/ceph/crystals/geometries/x23/bsse")
def make_crystal(name):
    structure = open(file_path/f"{name}.xyz")
    structure.readline()
    structure = structure.read()
    cell = gto.M()
    cell.atom = structure
    cell.unit='A'
    cell.a = open(file_path/f"{name}.alat").read()
    cell.build()
    return cell

def make_bsse(cell):
    crystal = make_crystal(cell)
    if args.tol:
        tol = float(args.tol)
    else:
        tol = 1.1
    bsse = bsse_molecular_crystal(crystal, 1, seq_tol=tol)[0] # use the first ref molecule
    if args.tol:
        bsse_file = open(save_path/f'{cell}_nshell1_mol0_tol.xyz', 'wt')
    else:
        bsse_file = open(save_path/f'{cell}_nshell1_mol0.xyz', 'wt')
    bsse_str = f'{len(bsse)}'+'\n\n'
    for i in bsse:
        coord = '   '.join(str(x) for x in i[1])
        atm = i[0]
        bsse_str += f'{atm}    {coord}' + '\n'
    bsse_file.write(bsse_str)
    bsse_file.close()
    return str

if __name__ == '__main__':
    make_bsse(args.file)
